import { create } from "zustand";
import { tasks as seedTasks, type Task, type TaskColumn } from "@/lib/mock-data";

interface AppState {
  theme: "light" | "dark";
  toggleTheme: () => void;
  tasks: Task[];
  moveTask: (id: string, column: TaskColumn) => void;
  toggleTask: (id: string) => void;
}

export const useAppStore = create<AppState>((set) => ({
  theme: "light",
  toggleTheme: () =>
    set((s) => {
      const theme = s.theme === "light" ? "dark" : "light";
      if (typeof document !== "undefined") {
        document.documentElement.classList.toggle("dark", theme === "dark");
      }
      return { theme };
    }),
  tasks: seedTasks,
  moveTask: (id, column) =>
    set((s) => ({
      tasks: s.tasks.map((t) =>
        t.id === id ? { ...t, column, done: column === "completed" } : t,
      ),
    })),
  toggleTask: (id) =>
    set((s) => ({
      tasks: s.tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)),
    })),
}));

import { Clock, CalendarDays } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { StatusBadge } from "./StatusBadge";
import { cn } from "@/lib/utils";
import type { Task } from "@/lib/mock-data";

export function TaskCard({
  task,
  onToggle,
  draggable,
  onDragStart,
}: {
  task: Task;
  onToggle?: (id: string) => void;
  draggable?: boolean;
  onDragStart?: (e: React.DragEvent) => void;
}) {
  return (
    <div
      draggable={draggable}
      onDragStart={onDragStart}
      className={cn(
        "card-surface p-4 transition-all duration-200 hover:shadow-[var(--shadow-lift)]",
        draggable && "cursor-grab active:cursor-grabbing",
        task.done && "opacity-70",
      )}
    >
      <div className="flex items-start gap-3">
        <Checkbox
          checked={task.done}
          onCheckedChange={() => onToggle?.(task.id)}
          className="mt-0.5"
          aria-label={`Toggle ${task.title}`}
        />
        <div className="min-w-0 flex-1">
          <p className={cn("text-sm font-medium", task.done && "line-through text-muted-foreground")}>
            {task.title}
          </p>
          <p className="truncate text-xs text-muted-foreground">{task.project}</p>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <StatusBadge status={task.priority} />
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" /> {task.time}
            </span>
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <CalendarDays className="h-3 w-3" /> {task.dueDate}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { TaskCard } from "@/components/founder/TaskCard";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/store/useAppStore";
import type { TaskColumn } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/tasks")({
  head: () => ({
    meta: [
      { title: "Tasks — FounderOS" },
      { name: "description", content: "Kanban board for solo delivery work: todo, in progress, review and completed with drag and drop." },
      { property: "og:title", content: "Tasks — FounderOS" },
      { property: "og:description", content: "A drag-and-drop kanban board for your delivery work." },
    ],
  }),
  component: TasksPage,
});

const columns: { id: TaskColumn; label: string; accent: string }[] = [
  { id: "todo", label: "Todo", accent: "bg-muted-foreground" },
  { id: "in-progress", label: "In progress", accent: "bg-primary" },
  { id: "review", label: "Review", accent: "bg-chart-5" },
  { id: "completed", label: "Completed", accent: "bg-success" },
];

function TasksPage() {
  const tasks = useAppStore((s) => s.tasks);
  const moveTask = useAppStore((s) => s.moveTask);
  const toggleTask = useAppStore((s) => s.toggleTask);
  const [dragging, setDragging] = useState<string | null>(null);
  const [over, setOver] = useState<TaskColumn | null>(null);

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader
        title="Tasks"
        description="Drag cards between columns to update status."
        actions={
          <Button onClick={() => toast.success("Task created (demo)")}>
            <Plus className="mr-1 h-4 w-4" /> New task
          </Button>
        }
      />

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        {columns.map((col) => {
          const items = tasks.filter((t) => t.column === col.id);
          return (
            <div
              key={col.id}
              onDragOver={(e) => { e.preventDefault(); setOver(col.id); }}
              onDragLeave={() => setOver(null)}
              onDrop={() => {
                if (dragging) moveTask(dragging, col.id);
                setDragging(null);
                setOver(null);
              }}
              className={cn(
                "flex flex-col gap-3 rounded-2xl border bg-muted/30 p-3 transition-colors",
                over === col.id && "border-primary/50 bg-primary/5",
              )}
            >
              <div className="flex items-center gap-2 px-1">
                <span className={cn("h-2 w-2 rounded-full", col.accent)} />
                <p className="text-sm font-medium">{col.label}</p>
                <span className="ml-auto rounded-full bg-background px-2 py-0.5 text-xs text-muted-foreground">
                  {items.length}
                </span>
              </div>
              {items.map((t) => (
                <TaskCard
                  key={t.id}
                  task={t}
                  onToggle={toggleTask}
                  draggable
                  onDragStart={() => setDragging(t.id)}
                />
              ))}
              {items.length === 0 && (
                <p className="rounded-xl border border-dashed px-3 py-8 text-center text-xs text-muted-foreground">
                  Drop tasks here
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Plus, Search } from "lucide-react";
import { PageHeader, EmptyState } from "@/components/layout/PageHeader";
import { ClientCard } from "@/components/founder/ClientCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { clients } from "@/lib/mock-data";
import { useFakeLoading } from "@/hooks/useFakeLoading";
import { toast } from "sonner";

export const Route = createFileRoute("/clients")({
  head: () => ({
    meta: [
      { title: "Clients — FounderOS" },
      { name: "description", content: "Browse, search and filter every client relationship with pending amounts and active project counts." },
      { property: "og:title", content: "Clients — FounderOS" },
      { property: "og:description", content: "All client relationships, contacts and pending balances in one place." },
    ],
  }),
  component: ClientsPage,
});

function ClientsPage() {
  const loading = useFakeLoading();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");

  const filtered = useMemo(
    () =>
      clients.filter(
        (c) =>
          (status === "all" || c.status === status) &&
          (c.name + c.company + c.email).toLowerCase().includes(query.toLowerCase()),
      ),
    [query, status],
  );

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader
        title="Clients"
        description={`${clients.length} relationships · ${clients.filter((c) => c.status === "active").length} active`}
        actions={
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-1 h-4 w-4" /> Add client
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add client</DialogTitle>
                <DialogDescription>Demo form — nothing is saved.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-3">
                <div className="grid gap-1.5">
                  <Label htmlFor="cname">Name</Label>
                  <Input id="cname" placeholder="Jane Doe" />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="ccompany">Company</Label>
                  <Input id="ccompany" placeholder="Acme Inc." />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="cemail">Email</Label>
                  <Input id="cemail" type="email" placeholder="jane@acme.com" />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={() => toast.success("Client added (demo)")}>Save client</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-56 flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search clients"
            className="pl-9"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
            <SelectItem value="lead">Lead</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-56 rounded-xl" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          title="No clients match"
          description="Try a different search term or clear the status filter."
          action={
            <Button variant="outline" onClick={() => { setQuery(""); setStatus("all"); }}>
              Reset filters
            </Button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((c) => (
            <ClientCard key={c.id} client={c} />
          ))}
        </div>
      )}
    </div>
  );
}

import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { FileText, Image as ImageIcon, FileSignature, Receipt, Upload, File } from "lucide-react";
import { PageHeader, EmptyState } from "@/components/layout/PageHeader";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { documents, type Doc } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/documents")({
  head: () => ({
    meta: [
      { title: "Documents — FounderOS" },
      { name: "description", content: "Quotations, invoices, agreements, requirement docs, PDFs and images organised in one grid." },
      { property: "og:title", content: "Documents — FounderOS" },
      { property: "og:description", content: "Every quotation, invoice and agreement in one library." },
    ],
  }),
  component: DocumentsPage,
});

const categories = ["All", "Quotations", "Invoices", "Agreements", "Requirement Docs", "PDFs", "Images"] as const;

const icons: Record<Doc["category"], typeof FileText> = {
  Quotations: Receipt,
  Invoices: Receipt,
  Agreements: FileSignature,
  "Requirement Docs": FileText,
  PDFs: File,
  Images: ImageIcon,
};

function DocumentsPage() {
  const [tab, setTab] = useState<string>("All");
  const list = tab === "All" ? documents : documents.filter((d) => d.category === tab);

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader
        title="Documents"
        description={`${documents.length} files across ${categories.length - 1} categories`}
        actions={
          <Button onClick={() => toast.success("Upload started (demo)")}>
            <Upload className="mr-1 h-4 w-4" /> Upload
          </Button>
        }
      />

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex-wrap">
          {categories.map((c) => (
            <TabsTrigger key={c} value={c}>
              {c}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {list.length === 0 ? (
        <EmptyState title="No documents here yet" description="Upload a file to start this category." />
      ) : (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-4">
          {list.map((d) => {
            const Icon = icons[d.category];
            return (
              <button
                key={d.id}
                onClick={() => toast(`Opening ${d.name}`)}
                className="card-surface flex flex-col items-start p-5 text-left transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[var(--shadow-lift)]"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <Icon className="h-5 w-5" />
                </span>
                <p className="mt-4 line-clamp-2 text-sm font-medium">{d.name}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {d.category} · {d.size}
                </p>
                <p className="mt-3 text-xs text-muted-foreground">Updated {d.updated}</p>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { ideas, type Idea } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/ideas")({
  head: () => ({
    meta: [
      { title: "Ideas — FounderOS" },
      { name: "description", content: "Sticky-note board for SaaS ideas, client requests, feature ideas and future plans." },
      { property: "og:title", content: "Ideas — FounderOS" },
      { property: "og:description", content: "Capture SaaS ideas, client requests and future plans on a sticky board." },
    ],
  }),
  component: IdeasPage,
});

const categories = ["All", "SaaS Ideas", "Client Requests", "Feature Ideas", "Future Plans"] as const;

const noteTone: Record<Idea["category"], string> = {
  "SaaS Ideas": "bg-primary/10 border-primary/20",
  "Client Requests": "bg-warning/15 border-warning/25",
  "Feature Ideas": "bg-success/10 border-success/20",
  "Future Plans": "bg-chart-5/10 border-chart-5/20",
};

function IdeasPage() {
  const [tab, setTab] = useState<string>("All");
  const list = tab === "All" ? ideas : ideas.filter((i) => i.category === tab);

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader
        title="Ideas"
        description="Everything worth building later, parked in one place."
        actions={
          <Button onClick={() => toast.success("Note added (demo)")}>
            <Plus className="mr-1 h-4 w-4" /> New note
          </Button>
        }
      />

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex-wrap">
          {categories.map((c) => (
            <TabsTrigger key={c} value={c}>
              {c}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {list.map((idea, i) => (
          <article
            key={idea.id}
            className={cn(
              "rounded-2xl border p-5 shadow-[var(--shadow-soft)] transition-transform duration-300 hover:-translate-y-1 hover:rotate-0",
              noteTone[idea.category],
              i % 3 === 0 ? "rotate-[-1deg]" : i % 3 === 1 ? "rotate-[0.6deg]" : "",
            )}
          >
            <p className="text-sm font-semibold">{idea.title}</p>
            <p className="mt-2 text-sm text-muted-foreground">{idea.body}</p>
            <p className="mt-4 text-xs text-muted-foreground">
              {idea.category} · {idea.createdAt}
            </p>
          </article>
        ))}
      </div>
    </div>
  );
}

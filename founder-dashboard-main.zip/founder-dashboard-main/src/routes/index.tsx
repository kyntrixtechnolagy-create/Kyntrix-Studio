import { createFileRoute, Link } from "@tanstack/react-router";
import {
  DollarSign,
  Clock,
  PiggyBank,
  FolderKanban,
  CheckCircle2,
  ListChecks,
  UserPlus,
  ArrowRight,
} from "lucide-react";
import { StatCard } from "@/components/founder/StatCard";
import { RevenueChart } from "@/components/founder/RevenueChart";
import { StatusBadge } from "@/components/founder/StatusBadge";
import { Timeline } from "@/components/founder/Timeline";
import { TaskCard } from "@/components/founder/TaskCard";
import { PageHeader, SectionCard } from "@/components/layout/PageHeader";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { currency, projects, totals, calendarEvents } from "@/lib/mock-data";
import { useAppStore } from "@/store/useAppStore";
import { useFakeLoading } from "@/hooks/useFakeLoading";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — FounderOS" },
      {
        name: "description",
        content:
          "FounderOS dashboard: revenue, pending payments, active projects, tasks and deadlines for a solo software studio.",
      },
      { property: "og:title", content: "Dashboard — FounderOS" },
      {
        property: "og:description",
        content: "Your solo business operating system: revenue, projects, payments and tasks in one view.",
      },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const loading = useFakeLoading();
  const tasks = useAppStore((s) => s.tasks);
  const toggleTask = useAppStore((s) => s.toggleTask);
  const todays = tasks.filter((t) => t.today);
  const recent = projects.slice(0, 6);

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader
        title="Good afternoon, Rahul"
        description="Here's how the studio is doing this month."
        actions={
          <Button asChild>
            <Link to="/projects">
              View projects <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {loading
          ? Array.from({ length: 7 }).map((_, i) => (
              <Skeleton key={i} className="h-[152px] rounded-xl" />
            ))
          : (
              [
                { label: "Total revenue", value: currency(totals.revenue), subtitle: "Year to date", icon: DollarSign, trend: 12.4, tone: "primary" as const },
                { label: "Pending amount", value: currency(totals.pending), subtitle: "Across 9 invoices", icon: Clock, trend: -3.1, tone: "warning" as const },
                { label: "Savings", value: currency(totals.savings), subtitle: "Reserve account", icon: PiggyBank, trend: 8.2, tone: "success" as const },
                { label: "Active projects", value: `${totals.activeProjects}`, subtitle: "In delivery", icon: FolderKanban, trend: 5, tone: "info" as const },
                { label: "Completed projects", value: `${totals.completedProjects}`, subtitle: "Shipped in 2026", icon: CheckCircle2, trend: 16.7, tone: "success" as const },
                { label: "Pending tasks", value: `${totals.pendingTasks}`, subtitle: "Across all boards", icon: ListChecks, trend: -6.5, tone: "destructive" as const },
                { label: "New leads", value: `${totals.newLeads}`, subtitle: "This month", icon: UserPlus, trend: 25, tone: "primary" as const },
              ].map((c) => <StatCard key={c.label} {...c} />)
            )}
      </div>

      <SectionCard
        title="Revenue analytics"
        action={<span className="text-xs text-muted-foreground">Revenue · Expenses · Profit</span>}
      >
        {loading ? <Skeleton className="h-[320px] rounded-xl" /> : <RevenueChart />}
      </SectionCard>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <SectionCard
          title="Recent projects"
          className="xl:col-span-2"
          action={
            <Button variant="ghost" size="sm" asChild>
              <Link to="/projects">All projects</Link>
            </Button>
          }
        >
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Project</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead className="w-[140px]">Progress</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Deadline</TableHead>
                  <TableHead className="text-right">Pending</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recent.map((p) => (
                  <TableRow key={p.id} className="cursor-pointer">
                    <TableCell className="font-medium">
                      <Link to="/projects/$projectId" params={{ projectId: p.id }}>
                        {p.name}
                      </Link>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{p.client}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress value={p.progress} className="h-1.5" />
                        <span className="w-8 text-xs text-muted-foreground">{p.progress}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={p.status} />
                    </TableCell>
                    <TableCell className="text-muted-foreground">{p.deadline}</TableCell>
                    <TableCell className="text-right font-medium">
                      {currency(p.price - p.advance)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </SectionCard>

        <SectionCard title="Upcoming deadlines">
          <Timeline
            items={calendarEvents.slice(0, 6).map((e) => ({
              title: e.title,
              meta: e.date.slice(5),
              description: `${e.type} · ${e.time}`,
              tone: e.type === "deadline" ? "destructive" : e.type === "payment" ? "success" : "primary",
            }))}
          />
        </SectionCard>
      </div>

      <SectionCard title="Today's tasks">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {todays.map((t) => (
            <TaskCard key={t.id} task={t} onToggle={toggleTask} />
          ))}
        </div>
      </SectionCard>
    </div>
  );
}

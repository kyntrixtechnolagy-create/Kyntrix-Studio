import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, SectionCard } from "@/components/layout/PageHeader";
import { CalendarWidget } from "@/components/founder/CalendarWidget";
import { StatusBadge } from "@/components/founder/StatusBadge";
import { calendarEvents } from "@/lib/mock-data";

export const Route = createFileRoute("/calendar")({
  head: () => ({
    meta: [
      { title: "Calendar — FounderOS" },
      { name: "description", content: "Monthly calendar with client meetings, project deadlines, payment due dates and tasks." },
      { property: "og:title", content: "Calendar — FounderOS" },
      { property: "og:description", content: "Meetings, deadlines, payments and tasks in one monthly view." },
    ],
  }),
  component: CalendarPage,
});

function CalendarPage() {
  const [selected, setSelected] = useState<string | undefined>();
  const list = selected ? calendarEvents.filter((e) => e.date === selected) : calendarEvents;

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <PageHeader title="Calendar" description="August 2026 · meetings, deadlines and payments." />
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <CalendarWidget selected={selected} onSelect={setSelected} />
        </div>
        <SectionCard title={selected ? `Events on ${selected}` : "All events"}>
          {list.length === 0 ? (
            <p className="rounded-xl border border-dashed px-4 py-10 text-center text-sm text-muted-foreground">
              Nothing scheduled for this day.
            </p>
          ) : (
            <ul className="space-y-3">
              {list.map((e) => (
                <li key={e.id} className="rounded-xl border p-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-medium">{e.title}</p>
                    <StatusBadge status={e.type} />
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {e.date} · {e.time}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </SectionCard>
      </div>
    </div>
  );
}
